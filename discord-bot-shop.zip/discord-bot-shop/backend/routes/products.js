const express = require('express');
const db = require('../db');

const router = express.Router();

function serialize(product) {
  return { ...product, features: JSON.parse(product.features_json) };
}

router.get('/', (req, res) => {
  const products = db.prepare('SELECT * FROM products WHERE active = 1 ORDER BY price ASC').all();
  res.json({ products: products.map(serialize) });
});

router.get('/:slug', (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE slug = ? AND active = 1').get(req.params.slug);
  if (!product) return res.status(404).json({ error: 'Produit introuvable.' });
  res.json({ product: serialize(product) });
});

module.exports = router;
