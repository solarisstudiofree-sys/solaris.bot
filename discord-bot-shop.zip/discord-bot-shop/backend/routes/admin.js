const express = require('express');
const db = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireAdmin);

// --- Statistiques globales -------------------------------------------------
router.get('/stats', (req, res) => {
  const totalUsers = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  const totalBots = db.prepare('SELECT COUNT(*) AS c FROM bots').get().c;
  const totalRevenue = db.prepare("SELECT COALESCE(SUM(amount),0) AS s FROM orders WHERE status = 'paid'").get().s;
  const paidOrders = db.prepare("SELECT COUNT(*) AS c FROM orders WHERE status = 'paid'").get().c;
  const pendingOrders = db.prepare("SELECT COUNT(*) AS c FROM orders WHERE status = 'pending'").get().c;
  const openTickets = db.prepare("SELECT COUNT(*) AS c FROM tickets WHERE status != 'closed'").get().c;

  res.json({ totalUsers, totalBots, totalRevenue, paidOrders, pendingOrders, openTickets });
});

// --- Utilisateurs -----------------------------------------------------------
router.get('/users', (req, res) => {
  const users = db.prepare('SELECT id, email, username, role, banned, created_at FROM users ORDER BY created_at DESC').all();
  res.json({ users });
});

router.patch('/users/:id', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });

  const { role, banned } = req.body;
  db.prepare('UPDATE users SET role = ?, banned = ? WHERE id = ?').run(
    role || user.role,
    banned === undefined ? user.banned : (banned ? 1 : 0),
    user.id
  );
  res.json({ ok: true });
});

// --- Commandes ---------------------------------------------------------------
router.get('/orders', (req, res) => {
  const orders = db.prepare(`
    SELECT orders.*, users.email AS user_email, products.name AS product_name
    FROM orders
    JOIN users ON users.id = orders.user_id
    JOIN products ON products.id = orders.product_id
    ORDER BY orders.created_at DESC
  `).all();
  res.json({ orders });
});

router.patch('/orders/:id', (req, res) => {
  const { status } = req.body; // paid | refunded | cancelled
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, order.id);
  res.json({ ok: true });
});

// --- Produits (CRUD) ----------------------------------------------------------
router.get('/products', (req, res) => {
  const products = db.prepare('SELECT * FROM products ORDER BY price ASC').all();
  res.json({ products: products.map((p) => ({ ...p, features: JSON.parse(p.features_json) })) });
});

router.post('/products', (req, res) => {
  const { slug, name, description, price, features, popular } = req.body;
  const info = db.prepare(`
    INSERT INTO products (slug, name, description, price, features_json, popular)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(slug, name, description, price, JSON.stringify(features || []), popular ? 1 : 0);
  res.json({ id: info.lastInsertRowid });
});

router.patch('/products/:id', (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Produit introuvable.' });

  const { name, description, price, features, popular, active } = req.body;
  db.prepare(`
    UPDATE products SET name = ?, description = ?, price = ?, features_json = ?, popular = ?, active = ?
    WHERE id = ?
  `).run(
    name ?? product.name,
    description ?? product.description,
    price ?? product.price,
    features ? JSON.stringify(features) : product.features_json,
    popular === undefined ? product.popular : (popular ? 1 : 0),
    active === undefined ? product.active : (active ? 1 : 0),
    product.id
  );
  res.json({ ok: true });
});

router.delete('/products/:id', (req, res) => {
  db.prepare('UPDATE products SET active = 0 WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// --- Bots (vue globale admin) --------------------------------------------------
router.get('/bots', (req, res) => {
  const bots = db.prepare(`
    SELECT bots.*, users.email AS user_email
    FROM bots JOIN users ON users.id = bots.user_id
    ORDER BY bots.created_at DESC
  `).all();
  res.json({ bots: bots.map((b) => ({ ...b, config: JSON.parse(b.config_json) })) });
});

// --- Logs des webhooks (toutes plateformes) ------------------------------------
router.get('/webhook-logs', (req, res) => {
  const logs = db.prepare(`
    SELECT webhook_logs.*, webhooks.label, webhooks.url, users.email AS user_email
    FROM webhook_logs
    JOIN webhooks ON webhooks.id = webhook_logs.webhook_id
    JOIN users ON users.id = webhooks.user_id
    ORDER BY webhook_logs.created_at DESC
    LIMIT 100
  `).all();
  res.json({ logs });
});

// --- Tickets support ------------------------------------------------------------
router.get('/tickets', (req, res) => {
  const tickets = db.prepare(`
    SELECT tickets.*, users.email AS user_email
    FROM tickets JOIN users ON users.id = tickets.user_id
    ORDER BY tickets.created_at DESC
  `).all();
  res.json({ tickets });
});

router.get('/tickets/:id/messages', (req, res) => {
  const messages = db.prepare('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC').all(req.params.id);
  res.json({ messages });
});

router.post('/tickets/:id/reply', (req, res) => {
  const { message } = req.body;
  db.prepare("INSERT INTO ticket_messages (ticket_id, sender, message) VALUES (?, 'admin', ?)").run(req.params.id, message);
  db.prepare("UPDATE tickets SET status = 'answered' WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
