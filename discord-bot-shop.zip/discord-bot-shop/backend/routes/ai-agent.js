const express = require('express');
const fetch = require('node-fetch');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { triggerWebhooks } = require('../webhookSender');

const router = express.Router();

const SYSTEM_PROMPT = `Tu es l'agent IA intégré à un bot Discord vendu par notre plateforme.
Le client te parle en langage naturel pour te demander de modifier la configuration de SON bot
(modules activés, préfixe, message de bienvenue, liste de mots interdits, etc.).

Voici le schéma de configuration actuel du bot (JSON) :
{{CURRENT_CONFIG}}

Réponds UNIQUEMENT avec un objet JSON valide, sans texte autour, au format exact :
{
  "reply": "réponse courte et sympathique expliquant ce que tu proposes ou ce que tu réponds",
  "action": null OR {
      "prefix": "nouveau préfixe (optionnel)",
      "name": "nouveau nom du bot (optionnel)",
      "config": { ...seulement les clés de config à changer... }
  }
}

Règles :
- Si la demande du client ne nécessite pas de modification (question, discussion), mets "action": null.
- Si une modification est possible, remplis "action" avec UNIQUEMENT les champs à changer (pas tout l'objet).
- Ne modifie jamais de champs sensibles comme un token ou une clé API.
- Reste concis dans "reply" (2-3 phrases maximum).`;

async function callClaude(currentConfig, history) {
  const systemPrompt = SYSTEM_PROMPT.replace('{{CURRENT_CONFIG}}', JSON.stringify(currentConfig));

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
      max_tokens: 600,
      system: systemPrompt,
      messages: history
    })
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error?.message || 'Erreur API Anthropic');
  }

  const text = (data.content || []).map((b) => b.text || '').join('');
  const cleaned = text.replace(/```json|```/g, '').trim();

  try {
    return JSON.parse(cleaned);
  } catch (e) {
    // Si le modèle n'a pas renvoyé du JSON pur, on retombe sur une réponse texte simple
    return { reply: text || "Désolé, je n'ai pas compris, peux-tu reformuler ?", action: null };
  }
}

// Historique de conversation pour un bot donné
router.get('/:botId/history', requireAuth, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id = ? AND user_id = ?').get(req.params.botId, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable.' });

  const messages = db.prepare(`
    SELECT * FROM ai_messages WHERE bot_id = ? ORDER BY created_at ASC
  `).all(bot.id);
  res.json({ messages });
});

// Envoyer un message à l'agent IA
router.post('/:botId/chat', requireAuth, async (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id = ? AND user_id = ?').get(req.params.botId, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable.' });

  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'Message requis.' });

  if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY.startsWith('sk-ant-xxx')) {
    return res.status(503).json({
      error: "L'agent IA n'est pas configuré. Ajoute ta clé ANTHROPIC_API_KEY dans le fichier .env du backend."
    });
  }

  db.prepare(`
    INSERT INTO ai_messages (user_id, bot_id, role, content) VALUES (?, ?, 'user', ?)
  `).run(req.user.id, bot.id, message);

  const previous = db.prepare(`
    SELECT role, content FROM ai_messages WHERE bot_id = ? ORDER BY created_at ASC LIMIT 20
  `).all(bot.id);

  const history = previous.map((m) => ({ role: m.role, content: m.content }));

  try {
    const currentConfig = JSON.parse(bot.config_json);
    const result = await callClaude(currentConfig, history);

    const info = db.prepare(`
      INSERT INTO ai_messages (user_id, bot_id, role, content, action_json)
      VALUES (?, ?, 'assistant', ?, ?)
    `).run(req.user.id, bot.id, result.reply || '', result.action ? JSON.stringify(result.action) : null);

    res.json({
      messageId: info.lastInsertRowid,
      reply: result.reply,
      action: result.action || null
    });
  } catch (err) {
    res.status(500).json({ error: `Erreur agent IA : ${err.message}` });
  }
});

// Appliquer une action proposée par l'agent IA à la config réelle du bot
router.post('/:botId/apply/:messageId', requireAuth, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id = ? AND user_id = ?').get(req.params.botId, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable.' });

  const aiMessage = db.prepare('SELECT * FROM ai_messages WHERE id = ? AND bot_id = ?').get(req.params.messageId, bot.id);
  if (!aiMessage || !aiMessage.action_json) return res.status(400).json({ error: 'Aucune action à appliquer.' });

  const action = JSON.parse(aiMessage.action_json);
  const currentConfig = JSON.parse(bot.config_json);
  const newConfig = action.config ? { ...currentConfig, ...action.config } : currentConfig;

  db.prepare('UPDATE bots SET prefix = ?, name = ?, config_json = ? WHERE id = ?').run(
    action.prefix || bot.prefix,
    action.name || bot.name,
    JSON.stringify(newConfig),
    bot.id
  );
  db.prepare('UPDATE ai_messages SET applied = 1 WHERE id = ?').run(aiMessage.id);

  const updatedBot = db.prepare('SELECT * FROM bots WHERE id = ?').get(bot.id);
  triggerWebhooks(req.user.id, 'ai.action_applied', {
    botId: bot.id,
    action,
    newConfig
  });

  res.json({ ok: true, bot: { ...updatedBot, config: JSON.parse(updatedBot.config_json) } });
});

module.exports = router;
