const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { triggerWebhooks } = require('../webhookSender');

const router = express.Router();

function serialize(bot) {
  return { ...bot, config: JSON.parse(bot.config_json) };
}

router.get('/me', requireAuth, (req, res) => {
  const bots = db.prepare('SELECT * FROM bots WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({ bots: bots.map(serialize) });
});

router.get('/:id', requireAuth, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable.' });
  res.json({ bot: serialize(bot) });
});

// Mise à jour manuelle (préfixe, message de bienvenue, modules activés, mots interdits, etc.)
router.patch('/:id', requireAuth, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable.' });

  const currentConfig = JSON.parse(bot.config_json);
  const { prefix, name, config } = req.body;
  const newConfig = config ? { ...currentConfig, ...config } : currentConfig;

  db.prepare('UPDATE bots SET prefix = ?, name = ?, config_json = ? WHERE id = ?').run(
    prefix || bot.prefix,
    name || bot.name,
    JSON.stringify(newConfig),
    bot.id
  );

  const updated = db.prepare('SELECT * FROM bots WHERE id = ?').get(bot.id);
  triggerWebhooks(req.user.id, 'bot.config_updated', { bot: serialize(updated) });
  res.json({ bot: serialize(updated) });
});

// Redémarrer / mettre en ligne-hors ligne (simulation)
router.post('/:id/status', requireAuth, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable.' });
  const { status } = req.body; // 'online' | 'offline' | 'restarting'
  db.prepare('UPDATE bots SET status = ? WHERE id = ?').run(status, bot.id);
  triggerWebhooks(req.user.id, 'bot.status_changed', { botId: bot.id, status });
  res.json({ ok: true, status });
});

module.exports = router;
