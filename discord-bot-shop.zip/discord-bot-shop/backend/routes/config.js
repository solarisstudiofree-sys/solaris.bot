const express = require('express');
const { isConfigured } = require('../paypal');

const router = express.Router();

// Le frontend a besoin du client id PayPal pour charger le SDK PayPal JS.
// Le client SECRET, lui, ne sort JAMAIS du backend.
router.get('/paypal', (req, res) => {
  res.json({
    configured: isConfigured(),
    clientId: isConfigured() ? process.env.PAYPAL_CLIENT_ID : null,
    currency: process.env.PAYPAL_CURRENCY || 'EUR'
  });
});

module.exports = router;
