const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', requireAuth, (req, res) => {
  const tickets = db.prepare('SELECT * FROM tickets WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({ tickets });
});

router.post('/', requireAuth, (req, res) => {
  const { subject, message } = req.body;
  if (!subject || !message) return res.status(400).json({ error: 'Sujet et message requis.' });

  const info = db.prepare('INSERT INTO tickets (user_id, subject) VALUES (?, ?)').run(req.user.id, subject);
  db.prepare("INSERT INTO ticket_messages (ticket_id, sender, message) VALUES (?, 'client', ?)").run(info.lastInsertRowid, message);
  res.json({ ticketId: info.lastInsertRowid });
});

router.get('/:id/messages', requireAuth, (req, res) => {
  const ticket = db.prepare('SELECT * FROM tickets WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!ticket) return res.status(404).json({ error: 'Ticket introuvable.' });
  const messages = db.prepare('SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC').all(ticket.id);
  res.json({ messages });
});

router.post('/:id/reply', requireAuth, (req, res) => {
  const ticket = db.prepare('SELECT * FROM tickets WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!ticket) return res.status(404).json({ error: 'Ticket introuvable.' });
  const { message } = req.body;
  db.prepare("INSERT INTO ticket_messages (ticket_id, sender, message) VALUES (?, 'client', ?)").run(ticket.id, message);
  db.prepare("UPDATE tickets SET status = 'open' WHERE id = ?").run(ticket.id);
  res.json({ ok: true });
});

module.exports = router;
