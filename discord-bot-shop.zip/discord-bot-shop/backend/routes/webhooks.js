const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { triggerWebhooks } = require('../webhookSender');

const router = express.Router();

const AVAILABLE_EVENTS = [
  'order.paid',
  'bot.created',
  'bot.status_changed',
  'bot.config_updated',
  'ai.action_applied'
];

router.get('/available-events', requireAuth, (req, res) => {
  res.json({ events: AVAILABLE_EVENTS });
});

router.get('/', requireAuth, (req, res) => {
  const webhooks = db.prepare('SELECT * FROM webhooks WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({
    webhooks: webhooks.map((w) => ({ ...w, events: JSON.parse(w.events_json) }))
  });
});

router.post('/', requireAuth, (req, res) => {
  const { label, url, events } = req.body;
  if (!url || !/^https?:\/\//.test(url)) return res.status(400).json({ error: 'URL de webhook invalide.' });

  const validEvents = (events || []).filter((e) => AVAILABLE_EVENTS.includes(e));
  const secret = crypto.randomBytes(24).toString('hex');

  const info = db.prepare(`
    INSERT INTO webhooks (user_id, label, url, events_json, secret)
    VALUES (?, ?, ?, ?, ?)
  `).run(req.user.id, label || 'Mon webhook', url, JSON.stringify(validEvents), secret);

  const webhook = db.prepare('SELECT * FROM webhooks WHERE id = ?').get(info.lastInsertRowid);
  res.json({ webhook: { ...webhook, events: JSON.parse(webhook.events_json) } });
});

router.patch('/:id', requireAuth, (req, res) => {
  const webhook = db.prepare('SELECT * FROM webhooks WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!webhook) return res.status(404).json({ error: 'Webhook introuvable.' });

  const { label, url, events, active } = req.body;
  const validEvents = events ? events.filter((e) => AVAILABLE_EVENTS.includes(e)) : JSON.parse(webhook.events_json);

  db.prepare(`
    UPDATE webhooks SET label = ?, url = ?, events_json = ?, active = ? WHERE id = ?
  `).run(
    label ?? webhook.label,
    url ?? webhook.url,
    JSON.stringify(validEvents),
    active === undefined ? webhook.active : (active ? 1 : 0),
    webhook.id
  );

  const updated = db.prepare('SELECT * FROM webhooks WHERE id = ?').get(webhook.id);
  res.json({ webhook: { ...updated, events: JSON.parse(updated.events_json) } });
});

router.delete('/:id', requireAuth, (req, res) => {
  const webhook = db.prepare('SELECT * FROM webhooks WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!webhook) return res.status(404).json({ error: 'Webhook introuvable.' });
  db.prepare('DELETE FROM webhooks WHERE id = ?').run(webhook.id);
  db.prepare('DELETE FROM webhook_logs WHERE webhook_id = ?').run(webhook.id);
  res.json({ ok: true });
});

// Envoie un événement de test au webhook pour vérifier que tout fonctionne
router.post('/:id/test', requireAuth, async (req, res) => {
  const webhook = db.prepare('SELECT * FROM webhooks WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!webhook) return res.status(404).json({ error: 'Webhook introuvable.' });

  const events = JSON.parse(webhook.events_json);
  const testEvent = events[0] || 'order.paid';
  const results = await triggerWebhooks(req.user.id, testEvent, { test: true, message: 'Ceci est un test.' });
  res.json({ ok: true, results });
});

router.get('/:id/logs', requireAuth, (req, res) => {
  const webhook = db.prepare('SELECT * FROM webhooks WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!webhook) return res.status(404).json({ error: 'Webhook introuvable.' });
  const logs = db.prepare('SELECT * FROM webhook_logs WHERE webhook_id = ? ORDER BY created_at DESC LIMIT 50').all(webhook.id);
  res.json({ logs });
});

module.exports = router;
