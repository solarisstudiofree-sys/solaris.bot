const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { triggerWebhooks } = require('../webhookSender');
const paypal = require('../paypal');

const router = express.Router();

// Logique commune : marque une commande comme payée + crée le bot associé.
// Utilisée à la fois par la capture PayPal réelle et par la simulation de démo.
function markOrderPaidAndCreateBot(order, userId) {
  db.prepare("UPDATE orders SET status = 'paid' WHERE id = ?").run(order.id);

  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(order.product_id);
  const botInfo = db.prepare(`
    INSERT INTO bots (user_id, order_id, product_id, name, invite_url, prefix, status)
    VALUES (?, ?, ?, ?, ?, ?, 'online')
  `).run(
    userId,
    order.id,
    product.id,
    `${product.name} Bot`,
    `https://discord.com/oauth2/authorize?client_id=REMPLACE_MOI&scope=bot&permissions=8`,
    '!'
  );

  const bot = db.prepare('SELECT * FROM bots WHERE id = ?').get(botInfo.lastInsertRowid);

  triggerWebhooks(userId, 'order.paid', { order, product: { id: product.id, name: product.name } });
  triggerWebhooks(userId, 'bot.created', { bot });

  return bot;
}

// Crée une commande "pending" pour un produit donné
router.post('/', requireAuth, (req, res) => {
  const { productId } = req.body;
  const product = db.prepare('SELECT * FROM products WHERE id = ? AND active = 1').get(productId);
  if (!product) return res.status(404).json({ error: 'Produit introuvable.' });

  const info = db
    .prepare('INSERT INTO orders (user_id, product_id, amount, status) VALUES (?, ?, ?, ?)')
    .run(req.user.id, product.id, product.price, 'pending');

  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(info.lastInsertRowid);
  res.json({ order });
});

// -----------------------------------------------------------------------
// 💳 PAYPAL — flux réel de paiement
// -----------------------------------------------------------------------

// 1) Le frontend appelle cette route quand le client clique sur le bouton PayPal.
//    On crée une commande PayPal correspondant au montant de la commande interne.
router.post('/:id/paypal/create', requireAuth, async (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  if (order.status === 'paid') return res.status(400).json({ error: 'Commande déjà payée.' });
  if (!paypal.isConfigured()) return res.status(503).json({ error: 'PayPal non configuré côté serveur (voir .env).' });

  try {
    const paypalOrder = await paypal.createPaypalOrder(order.amount, process.env.PAYPAL_CURRENCY || 'EUR');
    res.json({ paypalOrderId: paypalOrder.id });
  } catch (err) {
    res.status(500).json({ error: `Erreur PayPal : ${err.message}` });
  }
});

// 2) Une fois que le client a approuvé le paiement dans la fenêtre PayPal, le
//    frontend appelle cette route pour capturer (encaisser) réellement l'argent.
//    C'est SEULEMENT après une capture réussie que la commande passe "paid"
//    et que le bot est créé — jamais avant.
router.post('/:id/paypal/capture', requireAuth, async (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  if (order.status === 'paid') return res.status(400).json({ error: 'Commande déjà payée.' });

  const { paypalOrderId } = req.body;
  if (!paypalOrderId) return res.status(400).json({ error: 'paypalOrderId manquant.' });

  try {
    const capture = await paypal.capturePaypalOrder(paypalOrderId);
    if (capture.status !== 'COMPLETED') {
      return res.status(402).json({ error: `Paiement non finalisé (statut PayPal : ${capture.status}).` });
    }
    const bot = markOrderPaidAndCreateBot(order, req.user.id);
    res.json({ order: { ...order, status: 'paid' }, bot });
  } catch (err) {
    res.status(500).json({ error: `Erreur PayPal : ${err.message}` });
  }
});

// -----------------------------------------------------------------------
// ⚠️ Endpoint de démonstration : simule un paiement réussi SANS passer par
// PayPal. Utile en développement quand PAYPAL_CLIENT_ID/SECRET ne sont pas
// encore configurés. Le frontend ne l'utilise qu'en repli (voir shop.html).
// -----------------------------------------------------------------------
router.post('/:id/simulate-payment', requireAuth, (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!order) return res.status(404).json({ error: 'Commande introuvable.' });
  if (order.status === 'paid') return res.status(400).json({ error: 'Commande déjà payée.' });

  const bot = markOrderPaidAndCreateBot(order, req.user.id);
  res.json({ order: { ...order, status: 'paid' }, bot });
});

router.get('/me', requireAuth, (req, res) => {
  const orders = db.prepare(`
    SELECT orders.*, products.name AS product_name
    FROM orders JOIN products ON products.id = orders.product_id
    WHERE orders.user_id = ?
    ORDER BY orders.created_at DESC
  `).all(req.user.id);
  res.json({ orders });
});

module.exports = router;
