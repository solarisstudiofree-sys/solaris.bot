Auth.requireAdmin();

const adminUser = Auth.getUser();
document.getElementById('sidebar-username').textContent = adminUser.username;
document.getElementById('sidebar-email').textContent = adminUser.email;
document.getElementById('logout-link').onclick = (e) => { e.preventDefault(); Auth.logout(); };

let adminProducts = [];

const tabs = document.querySelectorAll('.sidebar a[data-tab]');
function showTab(name) {
  document.querySelectorAll('.tab-panel').forEach(p => p.style.display = 'none');
  document.getElementById(`panel-${name}`).style.display = 'block';
  tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === name));

  if (name === 'stats') loadStats();
  if (name === 'users') loadUsers();
  if (name === 'orders') loadAdminOrders();
  if (name === 'products') loadAdminProducts();
  if (name === 'bots') loadAdminBots();
  if (name === 'webhook-logs') loadAdminWebhookLogs();
  if (name === 'tickets') loadAdminTickets();
}
tabs.forEach(t => t.addEventListener('click', (e) => {
  e.preventDefault();
  showTab(t.dataset.tab);
  history.replaceState(null, '', '#' + t.dataset.tab);
}));
showTab(location.hash ? location.hash.slice(1) : 'stats');

// ------------------------------------------------------------------
async function loadStats() {
  const s = await api('/admin/stats');
  document.getElementById('admin-stats').innerHTML = `
    <div class="stat-card"><div class="label">Utilisateurs</div><div class="value">${s.totalUsers}</div></div>
    <div class="stat-card"><div class="label">Bots actifs</div><div class="value">${s.totalBots}</div></div>
    <div class="stat-card"><div class="label">Revenu total</div><div class="value">${formatPrice(s.totalRevenue)}</div></div>
    <div class="stat-card"><div class="label">Commandes payées</div><div class="value">${s.paidOrders}</div></div>
    <div class="stat-card"><div class="label">Commandes en attente</div><div class="value">${s.pendingOrders}</div></div>
    <div class="stat-card"><div class="label">Tickets ouverts</div><div class="value">${s.openTickets}</div></div>
  `;
}

// ------------------------------------------------------------------
async function loadUsers() {
  const { users } = await api('/admin/users');
  document.getElementById('users-body').innerHTML = users.map(u => `
    <tr>
      <td>${escapeHtml(u.email)}</td>
      <td>${escapeHtml(u.username)}</td>
      <td><span class="badge-status ${u.role}">${u.role}</span></td>
      <td>${u.banned ? '<span class="badge-status cancelled">Banni</span>' : '<span class="badge-status paid">Actif</span>'}</td>
      <td>${formatDate(u.created_at)}</td>
      <td class="flex gap-8">
        <button class="btn btn-secondary btn-sm" onclick="toggleRole(${u.id}, '${u.role}')">${u.role === 'admin' ? 'Rétrograder' : 'Promouvoir admin'}</button>
        <button class="btn ${u.banned ? 'btn-success' : 'btn-danger'} btn-sm" onclick="toggleBan(${u.id}, ${u.banned})">${u.banned ? 'Débannir' : 'Bannir'}</button>
      </td>
    </tr>
  `).join('');
}
async function toggleRole(id, role) {
  await api(`/admin/users/${id}`, { method: 'PATCH', body: { role: role === 'admin' ? 'client' : 'admin' } });
  loadUsers();
}
async function toggleBan(id, banned) {
  await api(`/admin/users/${id}`, { method: 'PATCH', body: { banned: !banned } });
  loadUsers();
}

// ------------------------------------------------------------------
async function loadAdminOrders() {
  const { orders } = await api('/admin/orders');
  document.getElementById('admin-orders-body').innerHTML = orders.map(o => `
    <tr>
      <td>#${o.id}</td>
      <td>${escapeHtml(o.user_email)}</td>
      <td>${escapeHtml(o.product_name)}</td>
      <td>${formatPrice(o.amount)}</td>
      <td><span class="badge-status ${o.status}">${o.status}</span></td>
      <td>${formatDate(o.created_at)}</td>
      <td class="flex gap-8">
        ${o.status !== 'paid' ? `<button class="btn btn-success btn-sm" onclick="setOrderStatus(${o.id}, 'paid')">Valider</button>` : ''}
        ${o.status !== 'refunded' ? `<button class="btn btn-danger btn-sm" onclick="setOrderStatus(${o.id}, 'refunded')">Remboursé</button>` : ''}
      </td>
    </tr>
  `).join('');
}
async function setOrderStatus(id, status) {
  await api(`/admin/orders/${id}`, { method: 'PATCH', body: { status } });
  loadAdminOrders();
}

// ------------------------------------------------------------------
async function loadAdminProducts() {
  const { products } = await api('/admin/products');
  adminProducts = products;
  document.getElementById('admin-products-list').innerHTML = products.map(p => `
    <div class="card">
      <div class="flex-between">
        <h3 style="margin:0;">${escapeHtml(p.name)} ${p.popular ? '⭐' : ''}</h3>
        <span class="badge-status ${p.active ? 'paid' : 'cancelled'}">${p.active ? 'Actif' : 'Désactivé'}</span>
      </div>
      <div class="price" style="font-size:1.4rem;margin:8px 0;">${formatPrice(p.price)}</div>
      <p class="text-muted" style="font-size:0.85rem;">${escapeHtml(p.description)}</p>
      <div class="flex gap-8">
        <button class="btn btn-secondary btn-sm" onclick="editProduct(${p.id})">Modifier</button>
        <button class="btn btn-danger btn-sm" onclick="disableProduct(${p.id})">${p.active ? 'Désactiver' : 'Déjà désactivé'}</button>
      </div>
    </div>
  `).join('');
}

let editingProductId = null;
document.getElementById('new-product-btn').onclick = () => {
  editingProductId = null;
  document.getElementById('product-modal-title').textContent = 'Nouveau produit';
  ['pd-slug','pd-name','pd-desc','pd-price','pd-features'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('pd-popular').checked = false;
  document.getElementById('product-modal').classList.add('open');
};
function editProduct(id) {
  const p = adminProducts.find(x => x.id === id);
  editingProductId = id;
  document.getElementById('product-modal-title').textContent = 'Modifier le produit';
  document.getElementById('pd-slug').value = p.slug;
  document.getElementById('pd-slug').disabled = true;
  document.getElementById('pd-name').value = p.name;
  document.getElementById('pd-desc').value = p.description;
  document.getElementById('pd-price').value = p.price;
  document.getElementById('pd-features').value = p.features.join('\n');
  document.getElementById('pd-popular').checked = !!p.popular;
  document.getElementById('product-modal').classList.add('open');
}
document.getElementById('pd-cancel').onclick = () => {
  document.getElementById('pd-slug').disabled = false;
  document.getElementById('product-modal').classList.remove('open');
};
document.getElementById('pd-save').onclick = async () => {
  const body = {
    slug: document.getElementById('pd-slug').value,
    name: document.getElementById('pd-name').value,
    description: document.getElementById('pd-desc').value,
    price: parseFloat(document.getElementById('pd-price').value),
    features: document.getElementById('pd-features').value.split('\n').map(f => f.trim()).filter(Boolean),
    popular: document.getElementById('pd-popular').checked
  };
  try {
    if (editingProductId) {
      await api(`/admin/products/${editingProductId}`, { method: 'PATCH', body });
    } else {
      await api('/admin/products', { method: 'POST', body });
    }
    document.getElementById('pd-slug').disabled = false;
    document.getElementById('product-modal').classList.remove('open');
    loadAdminProducts();
  } catch (e) { alert('Erreur : ' + e.message); }
};
async function disableProduct(id) {
  if (!confirm('Désactiver ce produit ? Il ne sera plus visible dans la boutique.')) return;
  await api(`/admin/products/${id}`, { method: 'DELETE' });
  loadAdminProducts();
}

// ------------------------------------------------------------------
async function loadAdminBots() {
  const { bots } = await api('/admin/bots');
  document.getElementById('admin-bots-body').innerHTML = bots.map(b => `
    <tr>
      <td>${escapeHtml(b.name)}</td>
      <td>${escapeHtml(b.user_email)}</td>
      <td>${escapeHtml(b.prefix)}</td>
      <td><span class="badge-status ${b.status}">${b.status}</span></td>
      <td>${formatDate(b.created_at)}</td>
    </tr>
  `).join('');
}

// ------------------------------------------------------------------
async function loadAdminWebhookLogs() {
  const { logs } = await api('/admin/webhook-logs');
  document.getElementById('admin-webhook-logs-body').innerHTML = logs.length ? logs.map(l => `
    <tr>
      <td>${escapeHtml(l.user_email)}</td>
      <td>${escapeHtml(l.label)}</td>
      <td>${l.event}</td>
      <td>${l.success ? '✅' : '❌'} ${l.response_status ?? ''}</td>
      <td>${formatDate(l.created_at)}</td>
    </tr>
  `).join('') : `<tr><td colspan="5" class="text-muted">Aucun log encore.</td></tr>`;
}

// ------------------------------------------------------------------
let currentTicketId = null;
async function loadAdminTickets() {
  const { tickets } = await api('/admin/tickets');
  document.getElementById('admin-tickets-body').innerHTML = tickets.length ? tickets.map(t => `
    <tr>
      <td>${escapeHtml(t.user_email)}</td>
      <td>${escapeHtml(t.subject)}</td>
      <td><span class="badge-status ${t.status}">${t.status}</span></td>
      <td>${formatDate(t.created_at)}</td>
      <td><button class="btn btn-secondary btn-sm" onclick="openTicketReply(${t.id})">Répondre</button></td>
    </tr>
  `).join('') : `<tr><td colspan="5" class="text-muted">Aucun ticket.</td></tr>`;
}
async function openTicketReply(id) {
  currentTicketId = id;
  const { messages } = await api(`/admin/tickets/${id}/messages`);
  document.getElementById('ticket-thread').innerHTML = messages.map(m => `
    <div class="ai-msg ${m.sender === 'admin' ? 'user' : 'assistant'}" style="max-width:100%;">${escapeHtml(m.message)}</div>
  `).join('');
  document.getElementById('tr-message').value = '';
  document.getElementById('ticket-reply-modal').classList.add('open');
}
document.getElementById('tr-cancel').onclick = () => document.getElementById('ticket-reply-modal').classList.remove('open');
document.getElementById('tr-save').onclick = async () => {
  await api(`/admin/tickets/${currentTicketId}/reply`, { method: 'POST', body: { message: document.getElementById('tr-message').value } });
  document.getElementById('ticket-reply-modal').classList.remove('open');
  loadAdminTickets();
};
