Auth.requireLogin();
if (Auth.isAdmin()) window.location.href = '/admin.html';

const user = Auth.getUser();
document.getElementById('sidebar-username').textContent = user.username;
document.getElementById('sidebar-email').textContent = user.email;
document.getElementById('logout-link').onclick = (e) => { e.preventDefault(); Auth.logout(); };

let allBots = [];
let allWebhooks = [];
let availableEvents = [];
let currentAiBotId = null;

// ------------------------------------------------------------------
// NAVIGATION (onglets)
// ------------------------------------------------------------------
const tabs = document.querySelectorAll('.sidebar a[data-tab]');
function showTab(name) {
  document.querySelectorAll('.tab-panel').forEach(p => p.style.display = 'none');
  document.getElementById(`panel-${name}`).style.display = 'block';
  tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === name));

  if (name === 'overview') loadOverview();
  if (name === 'bots') loadBots();
  if (name === 'ai') loadAiTab();
  if (name === 'webhooks') loadWebhooks();
  if (name === 'billing') loadOrders();
  if (name === 'support') loadTickets();
}
tabs.forEach(t => t.addEventListener('click', (e) => {
  e.preventDefault();
  showTab(t.dataset.tab);
  history.replaceState(null, '', '#' + t.dataset.tab);
}));
showTab(location.hash ? location.hash.slice(1) : 'overview');

if (new URLSearchParams(location.search).get('welcome')) {
  setTimeout(() => alert('🎉 Merci pour votre achat ! Votre bot est prêt dans l\'onglet "Mes bots".'), 200);
}

// ------------------------------------------------------------------
// OVERVIEW
// ------------------------------------------------------------------
async function loadOverview() {
  const [{ bots }, { orders }] = await Promise.all([api('/bots/me'), api('/orders/me')]);
  allBots = bots;
  const totalSpent = orders.filter(o => o.status === 'paid').reduce((s, o) => s + o.amount, 0);

  document.getElementById('overview-stats').innerHTML = `
    <div class="stat-card"><div class="label">Bots actifs</div><div class="value">${bots.length}</div></div>
    <div class="stat-card"><div class="label">Commandes payées</div><div class="value">${orders.filter(o=>o.status==='paid').length}</div></div>
    <div class="stat-card"><div class="label">Total dépensé</div><div class="value">${formatPrice(totalSpent)}</div></div>
  `;

  document.getElementById('overview-bots').innerHTML = bots.length ? bots.map(botCardHtml).join('') :
    `<div class="empty-state" style="grid-column:1/-1;">Vous n'avez pas encore de bot. <a href="/shop.html">Voir la boutique →</a></div>`;
}

function botCardHtml(bot) {
  return `
    <div class="card bot-card">
      <div class="bot-head">
        <div>
          <h3>${escapeHtml(bot.name)}</h3>
          <span class="tag">Préfixe : ${escapeHtml(bot.prefix)}</span>
        </div>
        <span class="badge-status ${bot.status}">${bot.status}</span>
      </div>
      <a href="${bot.invite_url}" target="_blank" class="btn btn-secondary btn-sm">Inviter sur mon serveur</a>
      <div class="flex gap-8">
        <button class="btn btn-secondary btn-sm" onclick="openBotModal(${bot.id})">⚙️ Configurer</button>
        <button class="btn btn-outline btn-sm" onclick="restartBot(${bot.id})">🔁 Redémarrer</button>
      </div>
    </div>
  `;
}

// ------------------------------------------------------------------
// BOTS
// ------------------------------------------------------------------
async function loadBots() {
  const { bots } = await api('/bots/me');
  allBots = bots;
  document.getElementById('bots-list').innerHTML = bots.length ? bots.map(botCardHtml).join('') :
    `<div class="empty-state" style="grid-column:1/-1;">Aucun bot pour le moment. <a href="/shop.html">Acheter un bot →</a></div>`;
}

async function restartBot(id) {
  await api(`/bots/${id}/status`, { method: 'POST', body: { status: 'restarting' } });
  loadBots(); loadOverview();
  setTimeout(async () => {
    await api(`/bots/${id}/status`, { method: 'POST', body: { status: 'online' } });
    loadBots(); loadOverview();
  }, 1500);
}

let editingBotId = null;
function openBotModal(botId) {
  const bot = allBots.find(b => b.id === botId) || allBots[0];
  if (!bot) return;
  editingBotId = bot.id;
  document.getElementById('bot-name').value = bot.name;
  document.getElementById('bot-prefix').value = bot.prefix;
  document.getElementById('bot-welcome').value = bot.config.welcome_message || '';
  document.getElementById('bot-banned-words').value = (bot.config.banned_words || []).join(', ');

  const modules = bot.config.modules || {};
  const labels = { moderation: 'Modération', music: 'Musique', leveling: 'Leveling / XP', ai_agent: 'Agent IA' };
  document.getElementById('bot-modules').innerHTML = Object.keys(labels).map(key => `
    <label class="toggle-row" style="border-top:none;">
      <span>${labels[key]}</span>
      <span class="switch">
        <input type="checkbox" data-module="${key}" ${modules[key] ? 'checked' : ''}>
        <span class="slider"></span>
      </span>
    </label>
  `).join('');

  document.getElementById('bot-modal').classList.add('open');
}
document.getElementById('bot-cancel').onclick = () => document.getElementById('bot-modal').classList.remove('open');
document.getElementById('bot-save').onclick = async () => {
  const modules = {};
  document.querySelectorAll('#bot-modules input[type=checkbox]').forEach(cb => modules[cb.dataset.module] = cb.checked);
  const bannedWords = document.getElementById('bot-banned-words').value.split(',').map(w => w.trim()).filter(Boolean);

  await api(`/bots/${editingBotId}`, {
    method: 'PATCH',
    body: {
      name: document.getElementById('bot-name').value,
      prefix: document.getElementById('bot-prefix').value,
      config: {
        modules,
        welcome_message: document.getElementById('bot-welcome').value,
        banned_words: bannedWords
      }
    }
  });
  document.getElementById('bot-modal').classList.remove('open');
  loadBots(); loadOverview();
};

// ------------------------------------------------------------------
// AGENT IA
// ------------------------------------------------------------------
async function loadAiTab() {
  if (!allBots.length) {
    const { bots } = await api('/bots/me');
    allBots = bots;
  }
  const select = document.getElementById('ai-bot-select');
  if (!allBots.length) {
    document.getElementById('ai-messages').innerHTML = `<p class="text-muted">Achetez un bot pour utiliser l'agent IA.</p>`;
    select.style.display = 'none';
    return;
  }
  select.style.display = 'block';
  select.innerHTML = allBots.map(b => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join('');
  select.onchange = () => { currentAiBotId = Number(select.value); loadAiHistory(); };
  currentAiBotId = Number(select.value);
  loadAiHistory();
}

async function loadAiHistory() {
  const box = document.getElementById('ai-messages');
  box.innerHTML = `<p class="text-muted">Chargement…</p>`;
  const { messages } = await api(`/ai/${currentAiBotId}/history`);
  if (!messages.length) {
    box.innerHTML = `<p class="text-muted">Aucun message pour l'instant. Essayez une des suggestions ci-dessous, ou écrivez votre propre demande.</p>`;
    return;
  }
  box.innerHTML = messages.map(renderAiMessage).join('');
  box.scrollTop = box.scrollHeight;
}

function renderAiMessage(m) {
  let actionHtml = '';
  if (m.action_json) {
    const action = JSON.parse(m.action_json);
    actionHtml = `
      <div class="action-box">
        <div><strong>Modification proposée :</strong></div>
        <pre style="white-space:pre-wrap;margin:6px 0;">${escapeHtml(JSON.stringify(action, null, 2))}</pre>
        ${m.applied
          ? '<span class="badge-status paid">✓ Appliquée</span>'
          : `<button class="btn btn-primary btn-sm" onclick="applyAiAction(${m.id})">Appliquer cette modification</button>`}
      </div>
    `;
  }
  return `<div class="ai-msg ${m.role}">${escapeHtml(m.content)}${actionHtml}</div>`;
}

async function applyAiAction(messageId) {
  try {
    await api(`/ai/${currentAiBotId}/apply/${messageId}`, { method: 'POST' });
    loadAiHistory();
    loadBots(); loadOverview();
  } catch (e) {
    alert('Erreur : ' + e.message);
  }
}

function sendSuggestion(text) {
  document.getElementById('ai-input').value = text;
  document.getElementById('ai-form').dispatchEvent(new Event('submit'));
}

document.getElementById('ai-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('ai-input');
  const message = input.value.trim();
  if (!message || !currentAiBotId) return;
  input.value = '';

  const box = document.getElementById('ai-messages');
  box.insertAdjacentHTML('beforeend', `<div class="ai-msg user">${escapeHtml(message)}</div>`);
  box.insertAdjacentHTML('beforeend', `<div class="ai-msg assistant" id="ai-loading">L'agent réfléchit…</div>`);
  box.scrollTop = box.scrollHeight;

  try {
    await api(`/ai/${currentAiBotId}/chat`, { method: 'POST', body: { message } });
    loadAiHistory();
  } catch (err) {
    document.getElementById('ai-loading').textContent = 'Erreur : ' + err.message;
  }
});

// ------------------------------------------------------------------
// WEBHOOKS
// ------------------------------------------------------------------
async function loadWebhooks() {
  const [{ webhooks }, { events }] = await Promise.all([api('/webhooks'), api('/webhooks/available-events')]);
  allWebhooks = webhooks;
  availableEvents = events;

  document.getElementById('webhooks-list').innerHTML = webhooks.length ? webhooks.map(w => `
    <div class="card">
      <div class="flex-between">
        <div>
          <strong>${escapeHtml(w.label)}</strong>
          <div class="text-muted" style="font-size:0.82rem;word-break:break-all;">${escapeHtml(w.url)}</div>
        </div>
        <span class="switch">
          <input type="checkbox" ${w.active ? 'checked' : ''} onchange="toggleWebhook(${w.id}, this.checked)">
          <span class="slider"></span>
        </span>
      </div>
      <div class="flex gap-8" style="flex-wrap:wrap;margin:10px 0;">
        ${w.events.map(ev => `<span class="tag">${ev}</span>`).join('') || '<span class="tag">Aucun événement sélectionné</span>'}
      </div>
      <div class="flex gap-8">
        <button class="btn btn-secondary btn-sm" onclick="testWebhook(${w.id})">Tester</button>
        <button class="btn btn-secondary btn-sm" onclick="showWebhookLogs(${w.id})">Voir les logs</button>
        <button class="btn btn-danger btn-sm" onclick="deleteWebhook(${w.id})">Supprimer</button>
      </div>
      <div id="wh-logs-${w.id}" class="mt-16" style="display:none;"></div>
    </div>
  `).join('') : `<div class="empty-state">Aucun webhook configuré encore.</div>`;
}

async function toggleWebhook(id, active) {
  await api(`/webhooks/${id}`, { method: 'PATCH', body: { active } });
}
async function deleteWebhook(id) {
  if (!confirm('Supprimer ce webhook ?')) return;
  await api(`/webhooks/${id}`, { method: 'DELETE' });
  loadWebhooks();
}
async function testWebhook(id) {
  try {
    const { results } = await api(`/webhooks/${id}/test`, { method: 'POST' });
    alert('Test envoyé. Résultat : ' + JSON.stringify(results));
  } catch (e) { alert('Erreur : ' + e.message); }
}
async function showWebhookLogs(id) {
  const el = document.getElementById(`wh-logs-${id}`);
  if (el.style.display === 'block') { el.style.display = 'none'; return; }
  const { logs } = await api(`/webhooks/${id}/logs`);
  el.innerHTML = logs.length ? `
    <div class="table-wrap"><table>
      <thead><tr><th>Événement</th><th>Statut HTTP</th><th>Date</th></tr></thead>
      <tbody>${logs.map(l => `
        <tr><td>${l.event}</td><td>${l.success ? '✅' : '❌'} ${l.response_status ?? ''}</td><td>${formatDate(l.created_at)}</td></tr>
      `).join('')}</tbody>
    </table></div>
  ` : `<p class="text-muted">Aucun log encore.</p>`;
  el.style.display = 'block';
}

document.getElementById('new-webhook-btn').onclick = async () => {
  if (!availableEvents.length) {
    const { events } = await api('/webhooks/available-events');
    availableEvents = events;
  }
  document.getElementById('wh-label').value = '';
  document.getElementById('wh-url').value = '';
  document.getElementById('wh-events').innerHTML = availableEvents.map(ev => `
    <label class="flex gap-8" style="font-size:0.88rem;"><input type="checkbox" value="${ev}"> ${ev}</label>
  `).join('');
  document.getElementById('webhook-modal').classList.add('open');
};
document.getElementById('wh-cancel').onclick = () => document.getElementById('webhook-modal').classList.remove('open');
document.getElementById('wh-save').onclick = async () => {
  const events = [...document.querySelectorAll('#wh-events input:checked')].map(cb => cb.value);
  try {
    await api('/webhooks', {
      method: 'POST',
      body: { label: document.getElementById('wh-label').value, url: document.getElementById('wh-url').value, events }
    });
    document.getElementById('webhook-modal').classList.remove('open');
    loadWebhooks();
  } catch (e) { alert('Erreur : ' + e.message); }
};

// ------------------------------------------------------------------
// BILLING
// ------------------------------------------------------------------
async function loadOrders() {
  const { orders } = await api('/orders/me');
  document.getElementById('orders-body').innerHTML = orders.length ? orders.map(o => `
    <tr>
      <td>#${o.id}</td>
      <td>${escapeHtml(o.product_name)}</td>
      <td>${formatPrice(o.amount)}</td>
      <td><span class="badge-status ${o.status}">${o.status}</span></td>
      <td>${formatDate(o.created_at)}</td>
    </tr>
  `).join('') : `<tr><td colspan="5" class="text-muted">Aucune commande.</td></tr>`;
}

// ------------------------------------------------------------------
// SUPPORT
// ------------------------------------------------------------------
async function loadTickets() {
  const { tickets } = await api('/tickets');
  document.getElementById('tickets-body').innerHTML = tickets.length ? tickets.map(t => `
    <tr>
      <td>${escapeHtml(t.subject)}</td>
      <td><span class="badge-status ${t.status}">${t.status}</span></td>
      <td>${formatDate(t.created_at)}</td>
      <td><button class="btn btn-secondary btn-sm" onclick="viewTicket(${t.id})">Voir</button></td>
    </tr>
  `).join('') : `<tr><td colspan="4" class="text-muted">Aucun ticket.</td></tr>`;
}

async function viewTicket(id) {
  const { messages } = await api(`/tickets/${id}/messages`);
  alert(messages.map(m => `[${m.sender}] ${m.message}`).join('\n\n'));
}

document.getElementById('new-ticket-btn').onclick = () => {
  document.getElementById('tk-subject').value = '';
  document.getElementById('tk-message').value = '';
  document.getElementById('ticket-modal').classList.add('open');
};
document.getElementById('tk-cancel').onclick = () => document.getElementById('ticket-modal').classList.remove('open');
document.getElementById('tk-save').onclick = async () => {
  try {
    await api('/tickets', { method: 'POST', body: { subject: document.getElementById('tk-subject').value, message: document.getElementById('tk-message').value } });
    document.getElementById('ticket-modal').classList.remove('open');
    loadTickets();
  } catch (e) { alert('Erreur : ' + e.message); }
};
