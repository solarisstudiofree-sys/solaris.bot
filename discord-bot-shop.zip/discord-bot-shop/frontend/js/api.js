// Petit client API réutilisable sur toutes les pages.
const API_BASE = '/api';

const Auth = {
  getToken() { return localStorage.getItem('token'); },
  getUser() {
    try { return JSON.parse(localStorage.getItem('user')); } catch { return null; }
  },
  setSession(token, user) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },
  isLoggedIn() { return !!this.getToken(); },
  isAdmin() { return this.getUser()?.role === 'admin'; },
  requireLogin() {
    if (!this.isLoggedIn()) window.location.href = '/login.html';
  },
  requireAdmin() {
    if (!this.isLoggedIn() || !this.isAdmin()) window.location.href = '/login.html';
  },
  logout() {
    this.clear();
    window.location.href = '/login.html';
  }
};

async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = Auth.getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(API_BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });

  let data = {};
  try { data = await res.json(); } catch { /* réponse vide */ }

  if (res.status === 401) {
    Auth.clear();
  }

  if (!res.ok) {
    throw new Error(data.error || `Erreur ${res.status}`);
  }
  return data;
}

function formatPrice(n) {
  return `${Number(n).toFixed(2).replace('.', ',')} €`;
}

function formatDate(iso) {
  return new Date(iso.replace(' ', 'T') + 'Z').toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });
}

function escapeHtml(str = '') {
  return str.replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
